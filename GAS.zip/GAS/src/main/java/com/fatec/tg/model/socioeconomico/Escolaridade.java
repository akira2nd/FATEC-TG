package com.fatec.tg.model.socioeconomico;

public enum Escolaridade {
	
	FUNDAMENTAL_COMPLETO,
	FUNDAMENTAL_INCOMPLETO,
	ENSINO_MEDIO_COMPLETO,
	ENSINO_MEDIO_INCOMPLETO,
	SUPERIOR_COMPLETO,
	SUPERIOR_INCOMPLETO;
	

}
