package com.fatec.tg.model.socioeconomico;

public enum EstadoCivil {
	
	CASADO,
	SOLTEIRO,
	VIUVO,
	DIVORCIADO;

}
