package com.fatec.tg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fatec.tg.model.servico.CadastroServico;


@Repository("cadastroServicoRepository")
public interface CadastroServicoRepository extends JpaRepository<CadastroServico, Integer> {

	List<CadastroServico> findByAtivo(String ativo);
	
}
