package com.fatec.tg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fatec.tg.model.servico.ServicosCursos;
import com.fatec.tg.repository.ServicosCursosRepository;

@Service("servicosCursosService")
public class ServicosCursosService {

	private ServicosCursosRepository servicosCursosRepository;

	@Autowired
	public ServicosCursosService(ServicosCursosRepository servicosCursosRepository) {
		this.servicosCursosRepository = servicosCursosRepository;
	}
	
	public void salvarServicoCurso(ServicosCursos servicosCursos) {
		servicosCursosRepository.save(servicosCursos);
	}
	
}
