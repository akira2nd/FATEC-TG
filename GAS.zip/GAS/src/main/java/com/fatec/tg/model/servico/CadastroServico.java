package com.fatec.tg.model.servico;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
@Entity
@Table(name="cadastro_servico")
public class CadastroServico {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_cad_servico")
	private Integer id;
	
	@NotEmpty(message="Preencher nome do serviço")
	@Column(name="nome_servico")
	private String nomeServico;
	
	@Column(name="criado_em")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date datacriacao;
	
	@Column(name="precisa_socioeconomico")
	private boolean precisaSocioeconomico;
	
	@Column(name="ativo")
	private boolean ativo;

	/*
	@ManyToOne
	private Usuario usuario;
	*/

}
