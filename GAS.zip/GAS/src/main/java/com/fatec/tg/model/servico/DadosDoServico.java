package com.fatec.tg.model.servico;

import javax.persistence.*;

import com.fatec.tg.model.socioeconomico.MembroFamiliar;
import com.fatec.tg.model.socioeconomico.Socioeconomico;

import lombok.Data;

@Data
//@Entity
//@Table(name="dados_do_servico")
public class DadosDoServico {
	
	// TODO arrumar
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_dados_servico")
	private Integer id;
	
	
	private CadastroServico cadastroServico;
	
	private Socioeconomico socioeconomico;
	
	private MembroFamiliar membroFamiliar;
	
	private Integer fonecontato;
	
	private boolean temLaptop;
}
