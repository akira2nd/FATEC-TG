package com.fatec.tg.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.model.Usuario;
import com.fatec.tg.model.atendimento.Atendimento;
import com.fatec.tg.service.AtendimentoService;
import com.fatec.tg.service.UsuarioService;

@Controller
public class AtendimentoController {
	
	@Autowired
	private UsuarioService usuarioService;
	@Autowired
	private AtendimentoService atendimentoService;
	
	@GetMapping(value="/sgas/atendimento")
	public ModelAndView novoAtendimento() {
		ModelAndView modelAndView = new ModelAndView();
		Atendimento atendimento = new Atendimento();
		modelAndView.addObject("atendimento", atendimento);
		modelAndView.setViewName("sgas/atendimento");
		
		return modelAndView;
	}
	
	@PostMapping(value="/sgas/atendimento")
	public ModelAndView salvarAtendimento(@Valid Atendimento atendimento, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
		}else {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			Usuario usuario = usuarioService.localizaUsuarioPorEmail(auth.getName());
			atendimento.setUsuario(usuario);
			atendimento.setDataAtendimento(new Date());
			atendimentoService.salvarAtendimento(atendimento);
			modelAndView.addObject("msgSucesso", "Atendimento Salvo");
			modelAndView.setViewName("/sgas/atendimento");
		}
		return modelAndView;
		
	}

}
