package com.fatec.tg.model;

public enum FormaDeContato {
	
	EMAIL,
	TELEFONE,
	WHATSAPP,
	FACEBOOK,
	PRESENCIAL,
	OUTROS;

}
