package com.fatec.tg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fatec.tg.model.servico.CadastroServico;
import com.fatec.tg.repository.CadastroServicoRepository;

@Service
public class CadastroServicoService {
	
	private CadastroServicoRepository cadastroServicoRepository;

	@Autowired
	public CadastroServicoService(CadastroServicoRepository cadastroServicoRepository) {
		this.cadastroServicoRepository = cadastroServicoRepository;
	}
	
	public void salvarServico(CadastroServico novoServico) {
		cadastroServicoRepository.save(novoServico);
	}
	
	public List<CadastroServico> listaServicos(){
		return cadastroServicoRepository.findAll();
	}
	
	public List<CadastroServico> listaServicoStatus(String status){
		return cadastroServicoRepository.findByAtivo(status);
	}
	
	public Optional<CadastroServico> buscaCadastro(Integer id) {
		return cadastroServicoRepository.findById(id);
	}

}
