package com.fatec.tg.model.servico;

import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
@Entity
@Table(name="aux_servico")
public class AuxServico {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_aux_servico")
	private Integer id;
	
	@Column(name="data_inicio")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dataInicio;
	
	@Column(name="data_fim")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dataFim;
	
	@Column(name="turma")
	private String turma;
	
	@Column(name="status")
	private String status;
	
	@Column(name="disponibilidade_na_semana")
	private boolean dispSemana;
	
	@Column(name="disponibilidade_no_fds", length = 3)
	private String dispSabados;
	
	@Column(name="ja_cursou", length = 3)
	private String cursou;
	
	@Column(name="concluiu", length = 3)
	private String concluiu;
	
	@Lob
	@Column(name="motivo_nao_concluiu", length=512)
	private String motivo;
	
	@Lob
	@Column(name="motivo_interesse", length=512)
	private String interesse;
	

}
