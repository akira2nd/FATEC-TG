package com.fatec.tg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fatec.tg.model.socioeconomico.Socioeconomico;
import com.fatec.tg.repository.SocioeconomicoRepository;

@Service("socioeconomicoService")
public class SocioeconomicoService {
	
	private SocioeconomicoRepository socioeconomicoRepository;

	@Autowired
	public SocioeconomicoService(SocioeconomicoRepository socioeconomicoRepository) {
		this.socioeconomicoRepository = socioeconomicoRepository;
	}
	
	public void salvarSocioeconomico(Socioeconomico socioeconomico) {
		for(int i = 0; i < socioeconomico.getMembrosFamilia().size(); i++) {
			socioeconomico.getMembrosFamilia().get(i).setSocioeconomico(socioeconomico);
		}
		
		for(int i = 0; i < socioeconomico.getDespesas().size(); i++) {
			socioeconomico.getDespesas().get(i).setSocioeconomico(socioeconomico);
		}
		socioeconomicoRepository.save(socioeconomico);
	}
	
	public Optional<Socioeconomico> buscaPorId(Integer id) {
		return socioeconomicoRepository.findById(id);
	}
	
	public List<Socioeconomico> buscaRegistroPorNome(String nome){
		return socioeconomicoRepository.findByNomeResponsavel(nome);
	}
	
	public Socioeconomico buscaRegistroPorCpf(String cpf){
		return socioeconomicoRepository.findByNumCpf(cpf);
	}
	
	public List<Socioeconomico> buscaRegistroPorRg(String rg){
		return socioeconomicoRepository.findByNumRg(rg);
	}

}
