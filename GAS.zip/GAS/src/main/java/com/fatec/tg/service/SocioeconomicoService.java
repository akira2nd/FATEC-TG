package com.fatec.tg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fatec.tg.model.socioeconomico.Socioeconomico;
import com.fatec.tg.repository.SocioeconomicoRepository;

@Service("socioeconomicoService")
public class SocioeconomicoService {
	
	private SocioeconomicoRepository socioeconomicoRepository;

	@Autowired
	public SocioeconomicoService(SocioeconomicoRepository socioeconomicoRepository) {
		this.socioeconomicoRepository = socioeconomicoRepository;
	}
	
	public void salvarSocioeconomico(Socioeconomico socioeconomico) {
		socioeconomicoRepository.save(socioeconomico);
	}
	

}
