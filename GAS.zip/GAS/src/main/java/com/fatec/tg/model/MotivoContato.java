package com.fatec.tg.model;

public enum MotivoContato {
	INFORMAÇÕES,
	SERVIÇOS,
	CURSOS,
	ENCAMINHAMENTO,
	OUTROS;
}
