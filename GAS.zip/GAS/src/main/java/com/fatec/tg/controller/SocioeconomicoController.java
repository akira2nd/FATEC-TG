package com.fatec.tg.controller;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.model.Usuario;
import com.fatec.tg.model.socioeconomico.MembroFamiliar;
import com.fatec.tg.model.socioeconomico.Socioeconomico;
import com.fatec.tg.service.MembroFamiliarService;
import com.fatec.tg.service.SocioeconomicoService;
import com.fatec.tg.service.UsuarioService;

@Controller
public class SocioeconomicoController {
	
	@Autowired
	private UsuarioService usuarioService;
	
	@Autowired
	private SocioeconomicoService socioeconomicoService;
	@Autowired
	private MembroFamiliarService membroFamiliarService;
	/*
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true , 10) );
	    //binder.setValidator(validator);
	    System.out.println(binder);
	}
	*/
	
	@GetMapping(value="/sgas/socioeconomico")
	public ModelAndView cadastrarSocioeconomico() {
		ModelAndView modelAndView = new ModelAndView();
		Socioeconomico socioeconomico = new Socioeconomico();
		//MembroFamiliar membroFamiliar = new MembroFamiliar();
		//membroFamiliar.setSocioeconomico(socioeconomico);
		//socioeconomico.getMembrosFamilia().add(membroFamiliar);
		modelAndView.addObject("socioeconomico", socioeconomico);
		modelAndView.setViewName("sgas/socioeconomico");
		return modelAndView;
	}
	
	@PostMapping(value="/sgas/socioeconomico")
	public ModelAndView salvarSocioeconomico(@Valid Socioeconomico socioeconomico, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
		}else {
			//Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			//Usuario usuario = usuarioService.localizaUsuarioPorEmail(auth.getName());
			socioeconomicoService.salvarSocioeconomico(socioeconomico);
			modelAndView.addObject("msgSucesso", "Socioeconomico Salvo");
			modelAndView.setViewName("sgas/socioeconomico");
		}
		
		return modelAndView;
	}
	
	@PostMapping(value="/sgas/socioeconomico", params= {"addMembro"})
	public String addMembro(final Socioeconomico socioeconomico, @RequestParam("addMembro") String addMembro, final BindingResult bindingResult) {

		MembroFamiliar membroFamiliar = new MembroFamiliar();
		membroFamiliar.setSocioeconomico(socioeconomico);
		socioeconomico.getMembrosFamilia().add(membroFamiliar);
		
		return "/sgas/socioeconomico";
	}
	
	@PostMapping(value="/sgas/socioeconomico", params= {"removeMembro"})
	public String removeMembro(final Socioeconomico socioeconomico, @RequestParam("removeMembro") String addMembro, final BindingResult bindingResult) {

		MembroFamiliar membroFamiliar = new MembroFamiliar();
		membroFamiliar.setSocioeconomico(socioeconomico);
		socioeconomico.getMembrosFamilia().add(membroFamiliar);
		
		return "/sgas/socioeconomico";
	}

}
