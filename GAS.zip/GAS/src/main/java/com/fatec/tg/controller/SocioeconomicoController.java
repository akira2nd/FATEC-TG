package com.fatec.tg.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.model.socioeconomico.Despesa;
import com.fatec.tg.model.socioeconomico.MembroFamiliar;
import com.fatec.tg.model.socioeconomico.Socioeconomico;
import com.fatec.tg.service.SocioeconomicoService;

@Controller
public class SocioeconomicoController {

//	@Autowired
//	private UsuarioService usuarioService;

	@Autowired
	private SocioeconomicoService socioeconomicoService;

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true, 10));
		// binder.setValidator(validator);

	}

	@GetMapping(value = "/sgas/socioeconomico")
	public ModelAndView cadastrarSocioeconomico() {
		ModelAndView modelAndView = new ModelAndView();
		Socioeconomico socioeconomico = new Socioeconomico();
		modelAndView.addObject("socioeconomico", socioeconomico);
		modelAndView.setViewName("sgas/socioeconomico");
		return modelAndView;
	}

	@PostMapping(value = "/sgas/socioeconomico")
	public ModelAndView salvarSocioeconomico(@Valid Socioeconomico socioeconomico,  BindingResult bindingResult, @RequestParam("dataDoc") Date[] datas,
			@RequestParam("arquivoDoc") MultipartFile[] arquivos, @RequestParam("valorDoc") Double[] valores,
			@RequestParam("tipoDoc") String[] tipos)
			throws IOException {
		ModelAndView modelAndView = new ModelAndView();
		if (bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
		} else {
			// Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			// Usuario usuario = usuarioService.localizaUsuarioPorEmail(auth.getName());

			for(int i = 0; i < datas.length; i++) {
				if(valores[i] != null) {
			
					Despesa despesa = new Despesa();
			
					despesa.setValor(valores[i]);
					despesa.setData(datas[i]);
					despesa.setTipo(tipos[i]);
					despesa.setNomeArquivo(StringUtils.cleanPath(arquivos[i].getOriginalFilename()));
		
					despesa.setArquivo(arquivos[i].getBytes());
			
					socioeconomico.getDespesas().add(despesa);
				}
			}
			
			socioeconomicoService.salvarSocioeconomico(socioeconomico);
			modelAndView.addObject("msgSucesso", "Socioeconomico Salvo");
			modelAndView.setViewName("sgas/socioeconomico");
		}

		return modelAndView;
	}

	@PostMapping(value = "/sgas/socioeconomico", params = { "addMembro" })
	public String addMembro(final Socioeconomico socioeconomico, @RequestParam("addMembro") String addMembro,
			final BindingResult bindingResult) {

		MembroFamiliar membroFamiliar = new MembroFamiliar();
		membroFamiliar.setSocioeconomico(socioeconomico);
		socioeconomico.getMembrosFamilia().add(membroFamiliar);

		return "/sgas/socioeconomico";
	}

	@PostMapping(value = "/sgas/socioeconomico", params = { "removeMembro" })
	public String removeMembro(final Socioeconomico socioeconomico, @RequestParam("removeMembro") String removeMembro,
			final BindingResult bindingResult, final HttpServletRequest req) {

		final Integer rowId = Integer.valueOf(req.getParameter("removeMembro"));
		socioeconomico.getMembrosFamilia().remove(rowId.intValue());

		return "/sgas/socioeconomico";
	}

}
