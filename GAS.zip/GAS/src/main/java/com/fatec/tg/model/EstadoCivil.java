package com.fatec.tg.model;

public enum EstadoCivil {
	
	CASADO,
	SOLTEIRO,
	VIUVO,
	DIVORCIADO;

}
