package com.fatec.tg.model.socioeconomico;

import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
@Entity
@Table(name="despesa")
public class Despesa{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="data")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date data;
	
	@Column(name="valor")
	private Double valor;
	
	@Column(name="tipo")
	private String tipo;
	
	@Lob
	@Column(name="arquivo", columnDefinition="mediumblob" )
	private byte[] arquivo;
	
	@Column(name="ativo")
	private boolean ativo;
	
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name="id_socioeconomico")
	private Socioeconomico socioeconomico;
	
	@Column(name="procedimento")
	private String procedimento;
}
