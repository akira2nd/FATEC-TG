package com.fatec.tg.model.socioeconomico;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
@Entity
@Table(name="despesa")
public class Despesa{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name="data")
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date data;
	
	@Column(name="valor")
	private Double valor;
	
	@Column(name="tipo")
	private String tipo;
	
	@Lob
	@Column(name="arquivo", columnDefinition="mediumblob" )
	//private File arquivo;
	private byte[] arquivo;
	
	//@Column(name="ativo")
	//private boolean ativo;
	
	@ManyToOne(fetch= FetchType.LAZY)
	@JoinColumn(name="id_socioeconomico")
	private Socioeconomico socioeconomico;
	
}
