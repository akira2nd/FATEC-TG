package com.fatec.tg.model.atendimento;

public enum FormaDeContato {
	
	EMAIL,
	TELEFONE,
	WHATSAPP,
	FACEBOOK,
	PRESENCIAL,
	OUTROS;

}
