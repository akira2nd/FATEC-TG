package com.fatec.tg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fatec.tg.model.atendimento.Atendimento;
import com.fatec.tg.repository.AtendimentoRepository;

@Service("atendimentoService")
public class AtendimentoService {
	
	private AtendimentoRepository atendimentoRepository;
	
	@Autowired
	public AtendimentoService(AtendimentoRepository atendimentoRepository) {
		this.atendimentoRepository = atendimentoRepository;
	}
	
	public void salvarAtendimento(Atendimento atendimento) {
		atendimentoRepository.save(atendimento);
	}
	
}
