package com.fatec.tg.model.servico;

import javax.persistence.*;

import com.fatec.tg.model.socioeconomico.MembroFamiliar;
import com.fatec.tg.model.socioeconomico.Socioeconomico;

import lombok.Data;

@Data
@Entity
@Table(name="servicos_e_cursos")
public class ServicosCursos {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_servico_curso")
	private Integer id;
	
	@OneToOne(cascade=CascadeType.ALL)
	private CadastroServico cadastroServico;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Socioeconomico socioeconomico;
	
	@OneToOne(cascade=CascadeType.ALL)
	private MembroFamiliar membroFamiliar;
	
	@Column(name="fone_contato")
	private Integer fonecontato;
	
	@Column(name="tem_laptop", length = 3)
	private String temLaptop;
	
	@Column(name="necessiade_especial")
	private String necessidadeEspecial;
	
	@OneToOne(cascade=CascadeType.ALL)
	private AuxServico opServico;
	
}
