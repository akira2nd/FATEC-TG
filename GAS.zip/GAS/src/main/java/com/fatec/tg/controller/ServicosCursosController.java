package com.fatec.tg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.service.CadastroServicoService;
import com.fatec.tg.service.SocioeconomicoService;

@Controller
public class ServicosCursosController {
	
	@Autowired
	private CadastroServicoService cadastroServicoService;
	@Autowired
	private SocioeconomicoService socioeconomicoService;
	
	@GetMapping(value="/sgas/servicos-cursos")
	public ModelAndView servicos() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("servicos", cadastroServicoService.listaServicoStatus("SIM"));
		modelAndView.setViewName("sgas/servicos-cursos");
		return modelAndView;
	}

	
	
}
