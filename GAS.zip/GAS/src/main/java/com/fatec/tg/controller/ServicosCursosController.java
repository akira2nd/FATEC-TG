package com.fatec.tg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.service.CadastroServicoService;
import com.fatec.tg.service.SocioeconomicoService;

@Controller
public class ServicosCursosController {
	
	@Autowired
	private CadastroServicoService cadastroServicoService;
	@Autowired
	private SocioeconomicoService socioeconomicoService;
	
	@GetMapping(value="/sgas/servicos-cursos")
	public ModelAndView servicos() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("servicos", cadastroServicoService.listaServicoStatus("SIM"));
		modelAndView.setViewName("sgas/servicos-cursos");
		return modelAndView;
	}
	
	@PostMapping(value = "/sgas/servicos-cursos", params = {"validaSocioeconomico"})
	public ModelAndView validaSocioeconomico(@RequestParam("opcao") String curso, @RequestParam("nome") String nome, @RequestParam("cpf") String cpf, @RequestParam("rg") String rg ) {
		ModelAndView modelAndView= new ModelAndView();
		if(cadastroServicoService.buscaCadastroPorNome(curso).getPrecisaSocioeconomico().equalsIgnoreCase("SIM")) {
			
		}
		
		return modelAndView;
	}

}
