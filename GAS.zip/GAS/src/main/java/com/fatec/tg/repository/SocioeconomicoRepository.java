package com.fatec.tg.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fatec.tg.model.socioeconomico.Socioeconomico;

public interface SocioeconomicoRepository extends JpaRepository<Socioeconomico, Integer> {

	
	
}
