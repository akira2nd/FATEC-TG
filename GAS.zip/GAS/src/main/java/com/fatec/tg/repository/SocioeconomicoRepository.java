package com.fatec.tg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fatec.tg.model.socioeconomico.Socioeconomico;

public interface SocioeconomicoRepository extends JpaRepository<Socioeconomico, Integer> {

	List<Socioeconomico> findByNomeResponsavel(String nome);
	List<Socioeconomico> findByNumRg(String rg);
	List<Socioeconomico> findByNumCpf(String cpf);
	
}
