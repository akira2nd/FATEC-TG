package com.fatec.tg.model.socioeconomico;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
@Entity
@Table(name="socioeconomico")
public class Socioeconomico {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id_socioeconomico")
	private Integer id;
	
	@Column(name="nome_responsavel")
	@NotEmpty(message="informe o nome do responsável familiar")
	private String nomeResponsavel;
	
	@Column(name="data_nascimento")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date dataNasc;
	
	@Column(name="num_rg")
	@NotEmpty(message="informe o numero do RG")
	private String numRg;
	
	@Column(name="num_cpf")
	@NotEmpty(message="informe o numero do CPF")
	private String numCpf;
	
	@Column(name="endereco")
	private String endereco;
	
	@Column(name="numero")
	private int numero;
	
	@Column(name="complemento")
	private String complemento;
	
	@Column(name="bairro")
	private String bairro;
	
	@Column(name="estado_civil")
	@Enumerated(EnumType.STRING)
	private EstadoCivil estadoCivil;
	
	@Column(name="escolaridade")
	@Enumerated(EnumType.STRING)
	private Escolaridade escolaridade;
	
	@Column(name="telefone")
	private String telefone;
	
	@Column(name="pofissao")
	private String profissao;
	
	@Column(name="funcao")
	private String funcao;
	
	@Column(name="renda", scale=2, length=10)
	private Double renda;
	
	@Column(name="membro_familiar_id")
	@OneToMany(mappedBy="socioeconomico", fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	private List<MembroFamiliar> membrosFamilia;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Habitacao habitacao;
	

	@OneToOne(cascade=CascadeType.ALL)
	private Saude saude;

	@Column(name="despesas_id")
	@OneToMany(mappedBy="socioeconomico", fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	private List<Despesa> despesas;

	public Socioeconomico() {
		super();
		this.membrosFamilia = new ArrayList<>();
		this.despesas = new ArrayList<>();
	}
	
}
