package com.fatec.tg.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.model.servico.CadastroServico;
import com.fatec.tg.service.CadastroServicoService;

@Controller
public class CadastroServicoController {

	@Autowired
	private CadastroServicoService cadastroServicoService;
	
	@GetMapping(value="/sgas/cadastro-servico")
	public ModelAndView servicos() {
		ModelAndView modelAndView = new ModelAndView();
		CadastroServico cadastroServico = new CadastroServico();
		modelAndView.addObject("listaServicos", cadastroServicoService.listaServicos());
		modelAndView.addObject("cadservico", cadastroServico);
		modelAndView.setViewName("sgas/cadastro-servico");
		return modelAndView;
	}
	
	@PostMapping(value="/sgas/cadastro-servico")
	public ModelAndView salvarServico(@Valid @ModelAttribute("cadservico") CadastroServico cadastroServico, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		if(bindingResult.hasErrors()) {
			//System.out.println(bindingResult.getAllErrors());
		}else {
			cadastroServico.setDatacriacao(new Date());
			cadastroServicoService.salvarServico(cadastroServico);
			modelAndView.addObject("cadservico", new CadastroServico());
			modelAndView.addObject("msgSucess", "sucesso");
		}
		modelAndView.addObject("listaServicos", cadastroServicoService.listaServicos());
		modelAndView.setViewName("sgas/cadastro-servico");
		return modelAndView;
	}

	@PostMapping(value = "/sgas/cadastro-servico", params = { "mudaNome" })
	public ModelAndView mudaNome(@RequestParam("mudaNome") Integer id, @RequestParam("nomeServico") String nome) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sgas/cadastro-servico");
		
		if(cadastroServicoService.buscaCadastro(id).isPresent()) {
			CadastroServico cadastro = cadastroServicoService.buscaCadastro(id).get();
			cadastro.setNomeServico(nome);
			cadastroServicoService.salvarServico(cadastro);
		}
		modelAndView.addObject("listaServicos", cadastroServicoService.listaServicos());
		modelAndView.addObject("cadservico", new CadastroServico());
		System.out.println(id);
		return modelAndView;
	}
	
	@PostMapping(value = "/sgas/cadastro-servico", params = { "mudaSocioeconomico" })
	public ModelAndView mudaSocioeconomico(@RequestParam("mudaSocioeconomico") Integer id, @RequestParam("precisaSocioeconomico") String valor) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sgas/cadastro-servico");
		
		if(cadastroServicoService.buscaCadastro(id).isPresent()) {
			CadastroServico cadastro = cadastroServicoService.buscaCadastro(id).get();
			if(valor.equalsIgnoreCase("SIM")) {
				cadastro.setPrecisaSocioeconomico("NÃO");
			}else {
				cadastro.setPrecisaSocioeconomico("SIM");
			}
			cadastroServicoService.salvarServico(cadastro);
		}
		modelAndView.addObject("listaServicos", cadastroServicoService.listaServicos());
		modelAndView.addObject("cadservico", new CadastroServico());
		return modelAndView;
	}
	
	@PostMapping(value = "/sgas/cadastro-servico", params = { "mudaAtivo" })
	public ModelAndView mudaAtivo(@RequestParam("mudaAtivo") Integer id, @RequestParam("ativo") String valor) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("sgas/cadastro-servico");
		
		if(cadastroServicoService.buscaCadastro(id).isPresent()) {
			CadastroServico cadastro = cadastroServicoService.buscaCadastro(id).get();
			if(valor.equalsIgnoreCase("SIM")) {
				cadastro.setAtivo("NÃO");
			}else {
				cadastro.setAtivo("SIM");
			}
			cadastroServicoService.salvarServico(cadastro);
		}
		modelAndView.addObject("listaServicos", cadastroServicoService.listaServicos());
		modelAndView.addObject("cadservico", new CadastroServico());
		return modelAndView;
	}
	
}
