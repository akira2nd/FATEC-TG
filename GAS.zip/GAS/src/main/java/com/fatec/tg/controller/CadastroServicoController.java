package com.fatec.tg.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fatec.tg.model.servico.CadastroServico;
import com.fatec.tg.service.CadastroServicoService;

@Controller
public class CadastroServicoController {

	@Autowired
	private CadastroServicoService cadastroServicoService;
	
	@GetMapping(value="/sgas/cadastro-servico")
	public ModelAndView servicos() {
		ModelAndView modelAndView = new ModelAndView();
		CadastroServico cadastroServico = new CadastroServico();
		modelAndView.addObject("listaServicos", cadastroServicoService.listaServicos());
		modelAndView.addObject("servico", cadastroServico);
		modelAndView.setViewName("sgas/cadastro-servico");
		return modelAndView;
	}
	
	@PostMapping(value="/sgas/cadastro-servico")
	public ModelAndView salvarServico(@Valid CadastroServico cadastroServico, BindingResult bindingResult) {
		ModelAndView modelAndView = new ModelAndView();
		if(bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
			modelAndView.addObject("servico", cadastroServico);
		}else {
			cadastroServico.setDatacriacao(new Date());
			cadastroServicoService.salvarServico(cadastroServico);

		}
		modelAndView.addObject("msgSucess", "sucesso");
		modelAndView.setViewName("sgas/cadastro-servico");
		return modelAndView;
	}
}
