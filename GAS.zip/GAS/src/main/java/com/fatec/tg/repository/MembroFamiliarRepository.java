package com.fatec.tg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fatec.tg.model.socioeconomico.MembroFamiliar;

@Repository("membroFamiliarRepository")
public interface MembroFamiliarRepository extends JpaRepository<MembroFamiliar, Integer> {

}
