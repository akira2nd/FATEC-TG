package com.fatec.tg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fatec.tg.model.atendimento.Atendimento;

@Repository("atendimentoRepository")
public interface AtendimentoRepository extends JpaRepository<Atendimento, Integer>{
	
}
