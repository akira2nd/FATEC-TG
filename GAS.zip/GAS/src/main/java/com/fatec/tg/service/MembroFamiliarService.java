package com.fatec.tg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fatec.tg.model.socioeconomico.MembroFamiliar;
import com.fatec.tg.repository.MembroFamiliarRepository;

@Service("membroFamiliarService")
public class MembroFamiliarService {
	
	private MembroFamiliarRepository membroFamiliarRepository;

	@Autowired
	public MembroFamiliarService(MembroFamiliarRepository membroFamiliarRepository) {
		this.membroFamiliarRepository = membroFamiliarRepository;
	}
	
	public void salvarMembro(MembroFamiliar membroFamiliar) {
		membroFamiliarRepository.save(membroFamiliar);
	}
	

}
