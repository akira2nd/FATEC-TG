package com.fatec.tg.model.atendimento;

public enum MotivoContato {
	INFORMAÇÕES,
	SERVIÇOS,
	CURSOS,
	ENCAMINHAMENTO,
	OUTROS;
}
