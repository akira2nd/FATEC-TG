package com.fatec.tg.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fatec.tg.model.servico.ServicosCursos;

@Repository("servicosCursosRepository")
public interface ServicosCursosRepository extends JpaRepository<ServicosCursos, Integer> {

}
