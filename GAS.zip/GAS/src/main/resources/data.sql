REPLACE INTO permissao values (1,"ADMIN");
REPLACE INTO permissao values (2,"USER");